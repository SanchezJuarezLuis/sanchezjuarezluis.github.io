### 4.1.2
+ [x] Select: add method `val()`

### 4.1.1
+ [x] Utils: add method `inObject`
+ [x] Metro.initWidgets: change check rule for defined component
+ [x] Input file: add click on then all elements parts
+ [x] App bar: fix `v-menu` usage
+ [x] Spacing: add `mx-*`, `px-*` classes 
+ [x] Examples: add examples presentation page
+ [x] Examples: add login form example `examples/forms/login.html`

### 4.1.0
+ [x] Side navigation: new component `sidemenu-simple`
+ [x] Button group: new behavior for `one` mode - all unchecked
+ [x] Select: add method `data()` for loading options at `runtime` 
+ [x] Scheme builder: new mixin
+ [x] Schemes: `darcula`, `red-alert`, `red-dark`, `sky-net`
+ [x] Schemes: add documentation.
+ [x] Color: move color classes `bg-*` and `fg-*` to `metro-color.css`
+ [x] Sizing: add classes `.h-vh-*`, `.w-vw-*` (5, 10, 25, 50, 75, 100)
+ [x] Pagination: move to `pagination.less`
+ [x] Breadcrumbs: move to `breadcrumbs.less`
+ [x] Wizard: fix sections height for IE11 and Edge
+ [x] Wizard: add click on complete section to navigate to it
+ [x] Navview: fixed background-color for `.pull-down` and `.holder` for IE11 and Edge 
+ [x] All: fix any minor bugs
+ [x] Examples: Select in runtime `examples/ajax/select.html`
+ [x] Examples: Color module 1 `examples/colors/color-schemes.html`
+ [x] Examples: Color module 2 `examples/colors/color-schemes-2.html`
+ [x] Examples: Color module 3 `examples/colors/color-schemes-3.html`
+ [x] Examples: Cube `examples/cube/cube.html`
+ [x] Examples: Cube custom function `examples/cube/cube-custom-func.html`
+ [x] Examples: Windows `examples/desktop/desktop.html`
+ [x] Examples: Dialogs `examples/dialogs/dialogs.html`
+ [x] Examples: Schemes `examples/schemes/schemes.html`
+ [x] Examples: Tiles `examples/tiles/start.html`

### 4.0.10
+ [x] App bar: fix `.app-bar-menu` dropped down for IE11 and Edge

### 4.0.9
+ [x] Checkbox: refactoring
+ [x] Radio: refactoring
+ [x] Input: fix for IE11 and Edge
+ [x] Ribbon menu: fix for IE11 and Edge
+ [x] ListView: fix for IE11
+ [x] TreeView: fix for IE11 Edge for checkboxes
+ [x] Subsystem: add method `Object.values` special for IE11

### 4.0.8
+ [x] Ribbon menu: fix it for button group

### 4.0.7
+ [x] Button group: fix it

### 4.0.6
+ [x] Dialog: fix method `Metro.dialog.toggle()`
+ [x] Notify: increase `z-index` for default container
+ [x] Window: add observing `data-cls-window` attribute
+ [x] Window: fix observing `data-cls-caption` and `data-cls-content` attribute
+ [x] Window: add method `show()` - this method add class `no-visible` to `window`
+ [x] Window: add method `hide()` - this method remove class `no-visible` from `window`
+ [x] Window: upd documentation

### 4.0.5
+ [x] Tiles: add `.tiles-group` class with sizes subclasses
+ [x] Metro: add methods `reinitPlugin`, `reinitPluginAll`

### 4.0.4
+ [x] Charms: remove `preventDefault` from click event
+ [x] Nuget: change target location for Metro 4
+ [x] Validator: add `radio` and `select` to validation
+ [x] Validator: add function `not`

### 4.0.3
+ [x] Validator: rename event `onValid` to `onValidate`
+ [x] Validator: add events `onErrorForm`, `onValidateForm`
+ [x] Validator: added `checkbox` validation (required function)

### 4.0.2
+ [x] Validator: change rules delimiter to `space` 

### 4.0.1
+ [x] Pickers: fix buttons behavior

### 4.0.0
Release

