####4.1.x
- [ ] Remove jQuery dependency 
- [ ] Dropdown not only display: block
- [ ] Calendar picker calendar as dialog on phones
- [ ] Carousel, for each slide own effect
- [ ] Carousel, add custom effect 
- [ ] Carousel, add thumbs
- [ ] Inheritance for video and audio players from media-player class
- [ ] Responsive drop left, right ?
- [ ] Keypad: extends positions to all
- [ ] Set value for inputs components with value attribute
- [ ] Add media state for horizontal menu

####4.x
- [ ] Layout manager ?